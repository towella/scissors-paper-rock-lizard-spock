Scissors Paper Rock Simulation — by Andrew Towell

Controls
- F: Toggle fullscreen
- R: Reset game
- P/Space: Toggle pause
- Period/Esc: Close game

Enjoy :)