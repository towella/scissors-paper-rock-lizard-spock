Scissors Paper Rock Simulation
Copyright Andrew Towell 2023

Controls
- F: Toggle fullscreen
- R: Reset game
- P/Space: Toggle pause
- Comma/Esc: Close game

Enjoy :)